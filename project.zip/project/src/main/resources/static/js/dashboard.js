$(document).ready(function () {
    function filterTable() {
        let nameValue = $('#nameSearch').val().toLowerCase();
        let descriptionValue = $('#descriptionSearch').val().toLowerCase();
        let priceValue = $('#priceSearch').val();

        $('#productTable tr').filter(function () {
            let name = $(this).find('td').eq(0).text().toLowerCase();
            let description = $(this).find('td').eq(1).text().toLowerCase();
            let price = $(this).find('td').eq(2).text();

            $(this).toggle(
                (name.indexOf(nameValue) > -1 || nameValue === "") &&
                (description.indexOf(descriptionValue) > -1 || descriptionValue === "") &&
                (price.indexOf(priceValue) > -1 || priceValue === "")
            );
        });
    }

    /***
     minden onchange eventnél meghívja a filterTable-funkciót
     ***/
    $('#nameSearch, #descriptionSearch, #priceSearch').on('keyup change', function () {
        filterTable();
    });

    /***
     ajax DELETE hívást indít a /product/delete url-re felhasználva az url-ben található azonosítót
     ***/
    $('.delete-button').click(function () {
        const productId = $(this).val();
         if (confirm('Are you sure you want to delete this product?')) {
             $.ajax({
                 url: '/product/delete',
                 type: 'DELETE',
                 contentType: 'application/json',
                 data: JSON.stringify({
                     productId: productId
                 }),
                 success: function (response) {
                     alert('Product deleted successfully!');
                     location.reload();
                 },
                 error: function (xhr, status, error) {
                     alert('Failed to delete the product.');
                 }
             });
         }
    });


});
