$(document).ready(function () {
    $('#productForm').submit(function (event) {
        event.preventDefault();

        /***
         az input mezőkben található adatokat elmenti agy json-be
         ***/
        const productData = {
            name: $('#name').val(),
            description: $('#description').val(),
            price: parseFloat($('#price').val()),
            quantity: parseInt($('#quantity').val())
        };


        /***
         ajax POST hívást indít a /product/create url-re az előbb megalkotaott Json-t használva
         ***/
        $.ajax({
            url: '/product/create',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(productData),
            success: function (response) {
                $('#result').html('<p style="color:green;">Product created successfully!</p>');
                $('#productForm')[0].reset();
            },
            error: function (xhr, status, error) {
                $('#result').html('<p style="color:red;">Failed to insert product. Please try again.</p>');
            }
        });
    });
});
