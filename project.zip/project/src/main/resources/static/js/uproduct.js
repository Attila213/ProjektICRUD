$(document).ready(function () {
    $('#productForm').submit(function (event) {
        event.preventDefault();

        var currentUrl = window.location.href;
        var urlParts = currentUrl.split('/');
        var productId = urlParts[urlParts.length - 1];

        const productData = {
            productId: parseInt(productId),
            name: $('#name').val(),
            description: $('#description').val(),
            price: parseFloat($('#price').val()),
            quantity: parseInt($('#quantity').val())
        };

        /***
         ajax POST hívást indít a /product/update url-re felhasználva az url-ben található azonosítót és
         az inputokban található értékeket
         ***/
        $.ajax({
            url: '/product/update',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(productData),
            success: function (response) {

                $('#result').html('<p style="color:green;">Product updated successfully!</p>');
                $('#productForm')[0].reset();
                window.location.replace("../dashboard");

            },
            error: function (xhr, status, error) {
                $('#result').html('<p style="color:red;">Failed to update product. Please try again.</p>');
            }
        });
    });
});
