INSERT INTO MEMBERS (FIRST_NAME, LAST_NAME, EMAIL, PHONE, ADDRESS, JOIN_DATE, PASSWORD) VALUES ('John', 'Doe', 'john.doe@example.com', '555-1234', '123 Elm Street, Springfield', CURRENT_TIMESTAMP, 'password123');
INSERT INTO MEMBERS (FIRST_NAME, LAST_NAME, EMAIL, PHONE, ADDRESS, JOIN_DATE, PASSWORD) VALUES ('Jane', 'Smith', 'jane.smith@example.com', '555-5678', '456 Oak Avenue, Springfield', CURRENT_TIMESTAMP, 'password456');
INSERT INTO MEMBERS (FIRST_NAME, LAST_NAME, EMAIL, PHONE, ADDRESS, JOIN_DATE, PASSWORD) VALUES ('Robert', 'Johnson', 'robert.johnson@example.com', '555-8765', '789 Pine Lane, Springfield', CURRENT_TIMESTAMP, 'password789');
INSERT INTO MEMBERS (FIRST_NAME, LAST_NAME, EMAIL, PHONE, ADDRESS, JOIN_DATE, PASSWORD) VALUES ('Emily', 'Davis', 'emily.davis@example.com', '555-4321', '101 Maple Road, Springfield', CURRENT_TIMESTAMP, 'password101');
INSERT INTO MEMBERS (FIRST_NAME, LAST_NAME, EMAIL, PHONE, ADDRESS, JOIN_DATE, PASSWORD) VALUES ('Michael', 'Brown', 'michael.brown@example.com', '555-2468', '202 Birch Street, Springfield', CURRENT_TIMESTAMP, 'password202');

-- Admin user
INSERT INTO MEMBERS (FIRST_NAME, LAST_NAME, EMAIL, PHONE, ADDRESS, JOIN_DATE, PASSWORD) VALUES ('Admin', 'User', 'admin@example.com', '555-0000', 'Admin Building, Springfield', CURRENT_TIMESTAMP, 'adminpassword');
