package com.example.demo.dao;

import com.example.demo.model.Product;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ProductDAO implements DAO<Product> {

    private static final Logger logger = LoggerFactory.getLogger(ProductDAO.class);
    private JdbcTemplate jdbcTemplate;

    public ProductDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    /***
     az adatbázisból lekért adatokat beletölti az arra kijelölt termékváltozókba az oszlop neve alapján
     ***/
    RowMapper<Product> rowMapper = (rs, rowNum) -> {
        Product product = new Product();
        product.setProductId(rs.getInt("product_id"));
        product.setName(rs.getString("name"));
        product.setDescription(rs.getString("description"));
        product.setPrice(rs.getDouble("price"));
        product.setQuantity(rs.getInt("quantity"));
        return product;
    };


    /***
     lekéri az adatbázisból a termék adatait az azonosító alapján és visszatér egy termék objektummal
     ***/
    @Override
    public Product get(int id) {
        String sql = "SELECT * FROM Products WHERE product_id = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, rowMapper);
    }


    /***
    a paraméterben kapott termék-t egy insert into utasítással beinzertálja az adatbázisba
     ***/
    @Override
    public int create(Product product) {
        String sql = "INSERT INTO Products (name, description, price, quantity) VALUES (?, ?, ?, ?)";
        return jdbcTemplate.update(sql,
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity());
    }

    /***
     frissíti a terméket egy új termék és a régi azonosító alapján
     ***/
    @Override
    public int update(Product product, int id) {
        String sql = "UPDATE Products SET name = ?, description = ?, price = ?, quantity = ? WHERE product_id = ?";
        return jdbcTemplate.update(sql,
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity(),
                id);
    }


    /***
     a paraméterben kapott azonosító alapján kitörli a teméket az adatbázisból
     ***/
    @Override
    public void delete(int id) {
        String sql = "DELETE FROM Products WHERE product_id = ?";
        jdbcTemplate.update(sql, id);
    }


    /***
     lekéri az összes termék adatait, beletölti a listába és visszatér a lista objektummal
     ***/
    @Override
    public List<Product> list() {
        String sql = "SELECT * FROM Products";
        return jdbcTemplate.query(sql, rowMapper);
    }

}
