package com.example.demo.conroller;

import ch.qos.logback.core.model.Model;
import com.example.demo.dao.ProductDAO;
import com.example.demo.model.Product;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import java.util.List;

@Controller
@RestController
@RequestMapping("/")
public class DashboardContoller {

    ProductDAO productDAO;

    public DashboardContoller(ProductDAO pdao){
        this.productDAO = pdao;
    }


    @GetMapping("/")
    public RedirectView redirect(Model model) {
        return new RedirectView("/dashboard");
    }

    /*
    egy modelt csinál ami betölti a dashboard.html-t
     */
    @GetMapping("/dashboard")
    public ModelAndView dashboard() {
        List<Product> products = productDAO.list();

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("dashboard");

        modelAndView.addObject("products", products);

        return modelAndView;
    }



}
