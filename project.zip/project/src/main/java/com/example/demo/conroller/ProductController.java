package com.example.demo.conroller;


import com.example.demo.dao.ProductDAO;
import com.example.demo.model.Product;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RestController
@RequestMapping("/product")
public class ProductController {
    private ProductDAO productDAO;
    public ProductController(ProductDAO dao){
        this.productDAO = dao;
    }

    /***
    a product postban kapott paramétert felhasználva meghívja a productDAO-ban található create metódust
    ha nem sikerült beinjektálni a terméket akkor egy hibaüzenettel tér vissza
     ***/
    @PostMapping("/create")
    public ResponseEntity<String> createProduct(@RequestBody Product product) {
        int result = productDAO.create(product);
        if (result > 0) {
            return ResponseEntity.status(HttpStatus.CREATED).body("Product inserted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to insert the product.");
        }
    }

    /***
    a product postban kapott paramétert felhasználva meghívja a productDAO-ban található create metódust
    ha nem sikerült beinjektálni a terméket akkor egy hibaüzenettel tér vissza
    ***/
    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteProduct(@RequestBody Product product) {
        productDAO.delete(product.getProductId());
        return ResponseEntity.status(HttpStatus.OK).body("Product deleted successfully.");
    }


    /***
     a product postban kapott paramétert felhasználva meghívja a productDAO-ban található update metódust
     ha nem sikerült beinjektálni a terméket akkor egy hibaüzenettel tér vissza
     ***/
    @PostMapping("/update")
    public ResponseEntity<String> update(@RequestBody Product product) {
        int result = productDAO.update(product,product.getProductId());
        if (result > 0) {
            return ResponseEntity.status(HttpStatus.CREATED).body("Product updated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update the product.");
        }
    }


    /***
     betölti a createProduct.html-t
     ***/
    @GetMapping("/createProduct")
    public ModelAndView createProduct() {

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("createProduct");
        return modelAndView;
    }

    /***
     az id változó segítségével betölt egy termékspecifikus oldalt ahol
     lekéri és visszaadja a termék adatait
     ***/
    @GetMapping("/updateProduct/{id}")
    public ModelAndView updateProduct(@PathVariable("id") int id) {
        ModelAndView modelAndView = new ModelAndView();

        Product product = productDAO.get(id);

        if (product == null) {
            modelAndView.setViewName("error");
            modelAndView.addObject("message", "Product not found.");
            return modelAndView;
        }

        modelAndView.setViewName("updateProduct");
        modelAndView.addObject("product", product);

        return modelAndView;
    }


}
